package xyz.stark.uuidclean;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.*;

public class UUIDClean extends JavaPlugin {

    // folder name + file extensions to remove for the offline UUID
    private static final String[][] TARGETS = {
            {"playerdata", ".dat"},
            {"playerdata", ".dat_old"},
            {"stats", ".json"},
            {"advancements", ".json"}
    };

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length != 1 || !(args[0].equalsIgnoreCase("preview") || args[0].equalsIgnoreCase("run"))) {
            sender.sendMessage("§e/uuidclean preview §7- عرض القائمة");
            sender.sendMessage("§e/uuidclean run §7- تنفيذ (ينقل ملفات الأوفلاين لمجلد deleted_offline)");
            return true;
        }
        boolean dry = args[0].equalsIgnoreCase("preview");

        File usercache = new File(Bukkit.getWorldContainer(), "usercache.json");
        if (!usercache.exists()) {
            sender.sendMessage("§cusercache.json مو موجود.");
            return true;
        }

        File worldDir = Bukkit.getWorlds().get(0).getWorldFolder();
        File trash = new File(getDataFolder(), "deleted_offline");

        Map<String, Set<UUID>> byName = new LinkedHashMap<>();
        try (Reader r = new FileReader(usercache, StandardCharsets.UTF_8)) {
            JsonArray arr = JsonParser.parseReader(r).getAsJsonArray();
            for (JsonElement el : arr) {
                String name = el.getAsJsonObject().get("name").getAsString();
                UUID id = UUID.fromString(el.getAsJsonObject().get("uuid").getAsString());
                byName.computeIfAbsent(name, k -> new HashSet<>()).add(id);
            }
        } catch (Exception e) {
            sender.sendMessage("§cخطأ بقراءة usercache.json: " + e.getMessage());
            return true;
        }

        int players = 0, files = 0;
        for (Map.Entry<String, Set<UUID>> en : byName.entrySet()) {
            String name = en.getKey();
            UUID off = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
            if (!en.getValue().contains(off)) continue;

            UUID online = null;
            for (UUID id : en.getValue()) {
                if (!id.equals(off) && new File(worldDir, "playerdata/" + id + ".dat").exists()) {
                    online = id;
                    break;
                }
            }
            if (online == null) continue;

            // skip if this offline UUID is connected right now
            if (Bukkit.getPlayer(off) != null) {
                sender.sendMessage("§eتخطي (متصل حالياً): " + name);
                continue;
            }

            int moved = 0;
            for (String[] t : TARGETS) {
                File src = new File(worldDir, t[0] + "/" + off + t[1]);
                if (!src.exists()) continue;
                moved++;
                if (!dry) {
                    try {
                        File destDir = new File(trash, t[0]);
                        destDir.mkdirs();
                        Files.move(src.toPath(), new File(destDir, src.getName()).toPath(),
                                StandardCopyOption.REPLACE_EXISTING);
                    } catch (Exception e) {
                        sender.sendMessage("§cفشل نقل " + src.getName() + ": " + e.getMessage());
                        moved--;
                    }
                }
            }
            if (moved > 0) {
                players++;
                files += moved;
                sender.sendMessage("§7" + name + " §8| §c" + off + " §7← §a" + online + " §8(" + moved + " ملف)");
            }
        }

        sender.sendMessage((dry ? "§e[تجربة] " : "§a[تم] ") + "لاعبين: " + players + " | ملفات: " + files);
        if (dry) sender.sendMessage("§7نفّذ §e/uuidclean run §7للتطبيق.");
        return true;
    }
}
